# Registro Competencial Infantil — LOMLOE

Herramienta web gratuita para que el profesorado de Educación Infantil registre desde móvil o tablet el grado de consecución de los criterios de evaluación oficiales (Real Decreto 95/2022).

**Demo en vivo:** https://eliwankenobi.github.io/ewicia-registro/

## ¿Qué hace?

- Registra observaciones competenciales durante la jornada, con solo tocar botones.
- Soporta los dos ciclos (0-3 y 3-6) y las 17 comunidades autónomas.
- Funciona offline: una vez abierta, no necesita internet.
- Exporta los datos en Excel (.xlsx), directamente compatible con [EWicIA Desktop](https://ewicia.com) para generar informes competenciales automáticamente.

## Cómo se usa

1. Abrir la web desde el navegador del móvil o tablet.
2. En móvil: "Añadir a pantalla de inicio" → queda como una app.
3. Configurar el grupo una vez: nombre, ciclo, normativa aplicable, lista de alumnos.
4. En el aula: elegir modo "Por alumno" o "Por criterio" y tocar los niveles de consecución observados.
5. Al final del trimestre: exportar el Excel y subirlo a EWicIA para generar los informes.

## Niveles de consecución

En la app se registran los niveles LOMLOE. Al exportar a Excel para EWicIA, se convierten automáticamente a la escala 1-10 que procesa EWicIA:

| LOMLOE | Abr. | Nombre                       | Excel EWicIA |
| ------ | ---- | ---------------------------- | ------------ |
| 1      | IN   | Iniciado                     | 3            |
| 2      | EP   | En proceso                   | 5            |
| 3      | CO   | Conseguido                   | 8            |
| 4      | CA   | Conseguido con ampliación    | 10           |

Los criterios no evaluados aparecen en el Excel como "-" (guion).

## Formato del Excel exportado

El archivo tiene tres hojas:

**Hoja "Registro"** (la que procesa EWicIA):
- Primera columna: nombre del alumno.
- Columnas siguientes: un criterio de evaluación por columna. Encabezado con el formato `A1·1.1 Texto completo del criterio...` donde `A1` es el área y `1.1` el código del criterio dentro de su competencia específica.
- Cada fila: un alumno con su nota numérica o "-" si no evaluado.

**Hoja "Referencia"**: mapeo completo de cada criterio a su área y competencia específica. Útil para consulta rápida del docente.

**Hoja "Metadatos"**: grupo, ciclo, normativa, fecha de exportación, escala de notas.

## Privacidad

Los datos se guardan exclusivamente en el navegador del dispositivo (localStorage). No se envían a ningún servidor. Exporta copias de seguridad con regularidad.

**Recomendación RGPD:** usa iniciales o códigos (ALM001, ALM002…) en la app y guarda el mapeo a nombres reales fuera de ella, en el ordenador del centro.

## Criterios de evaluación

Los 82 criterios están transcritos literalmente desde el BOE (Real Decreto 95/2022). Los textos legales publicados en diarios oficiales no están sujetos a propiedad intelectual (art. 13 TRLPI).

- 33 criterios para el primer ciclo (0-3 años)
- 49 criterios para el segundo ciclo (3-6 años)

Fuente autoritativa: https://www.boe.es/eli/es/rd/2022/02/01/95/con

## Integración con EWicIA

EWicIA Desktop v2.0.1+ lee el Excel generado sin configuración adicional:

1. En EWicIA: seleccionar etapa "Educación Infantil" + ciclo correspondiente.
2. Seleccionar "Informe Global (Todas las áreas)" o un área concreta.
3. Subir el archivo .xlsx exportado desde esta PWA.
4. EWicIA detecta automáticamente las competencias y genera los informes.

**Nota técnica para EWicIA:** en `createPromptInfantil()`, se recomienda filtrar las notas con valor `"-"` antes de añadirlas al prompt, para que la IA no interprete los criterios no evaluados como calificaciones bajas:

```javascript
for (const [criterio, nota] of Object.entries(student.grades)) {
    if (nota === '-' || nota === '' || nota == null) continue;  // saltar no evaluados
    evaluacionInfo += `${criterio}: ${nota}/10\n`;
}
```

## Desarrollo

Proyecto de archivo único con librería externa local:

```
.
├── index.html                 # App completa
├── manifest.webmanifest       # Manifest PWA
├── sw.js                      # Service worker (offline)
├── lib/
│   └── xlsx.mini.min.js       # SheetJS 0.18.5 (generación Excel)
└── icons/                     # Iconos PWA
```

Para desarrollar localmente:

```bash
python3 -m http.server 8000
# abrir http://localhost:8000
```

No hay build step, ni dependencias npm, ni nada más. SheetJS se sirve local para garantizar funcionamiento offline completo.

## Licencia

Código: MIT. Textos de los criterios: dominio público (BOE, art. 13 TRLPI). SheetJS: licencia Apache 2.0.

## Autor

Eliseo Vercher ([EliwanKenobi](https://github.com/EliwanKenobi)) — Autor de EWicIA.
