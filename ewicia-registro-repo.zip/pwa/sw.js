/**
 * Service Worker - Registro Competencial Infantil
 *
 * Estrategia: cache-first con actualización en segundo plano (stale-while-revalidate).
 * Al actualizar la versión del cache, el SW limpia las versiones antiguas.
 *
 * Para forzar una actualización en los dispositivos de los maestros cuando
 * saques una nueva versión, cambia CACHE_VERSION abajo.
 */

const CACHE_VERSION = 'v1.1.0';
const CACHE_NAME = `registro-ei-${CACHE_VERSION}`;

// Recursos que se cachean en la instalación
const PRECACHE_ASSETS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './lib/xlsx.mini.min.js',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png',
  './icons/favicon.png'
];

// --- Instalación: precargar el cache ---
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_ASSETS);
    }).then(() => self.skipWaiting())
  );
});

// --- Activación: limpiar caches antiguos ---
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) => {
      return Promise.all(
        names
          .filter((name) => name.startsWith('registro-ei-') && name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    }).then(() => self.clients.claim())
  );
});

// --- Fetch: stale-while-revalidate ---
self.addEventListener('fetch', (event) => {
  // Solo cacheamos GET y peticiones al mismo origen
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== location.origin) return;

  event.respondWith(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.match(event.request).then((cachedResponse) => {
        const networkFetch = fetch(event.request).then((networkResponse) => {
          // Guardar copia fresca en el cache si es una respuesta OK
          if (networkResponse && networkResponse.status === 200) {
            cache.put(event.request, networkResponse.clone());
          }
          return networkResponse;
        }).catch(() => {
          // Sin red: devolvemos lo que tenemos en cache (o index como fallback)
          return cachedResponse || cache.match('./index.html');
        });

        // Devolver cache si existe, actualizar en segundo plano
        return cachedResponse || networkFetch;
      });
    })
  );
});
